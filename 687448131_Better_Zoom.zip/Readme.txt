Downloaded from SkyMods:

http://stellaris.smods.ru
https://plus.google.com/u/0/communities/100644482381435508067

Stellaris: Mods Catalogue

HOW TO INSTALL MODS

Unpack mod folder in
C:\Users\*Username*\Documents\Paradox Interactive\Stellaris\workshop\content\281990\

Unpack .mod file in
C:\Users\*Username*\Documents\Paradox Interactive\Stellaris\mod

Enable desired mods from the launcher, and click Play button.
Enjoy the game:)